package com.smarttravelling.smarttravelling121212.Adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.smarttravelling.smarttravelling121212.Home;
import com.smarttravelling.smarttravelling121212.MainActivity;
import com.smarttravelling.smarttravelling121212.R;
import com.smarttravelling.smarttravelling121212.SessionManager.SessionManager;

import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    Activity activity;
    ArrayList<String> arrayList;
    SessionManager sessionManager;

    public MainAdapter(Activity activity, ArrayList<String> arrayList) {
        this.activity = activity;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public MainAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_drawer_main,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MainAdapter.ViewHolder holder, int position) {
        holder.text.setText(arrayList.get(position));

        holder.textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = holder.getAdapterPosition();

                switch (position){
                    case 0:
                        activity.startActivity(new Intent(activity, Home.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        break;
                    case 1:
                        Toast.makeText(activity, "My Profile", Toast.LENGTH_SHORT).show();
                        break;
                    case 2:
                        Toast.makeText(activity, "Landmark Detection", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;
                    case 3:
                        Toast.makeText(activity, "Find Hotels", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;
                    case 4:
                        Toast.makeText(activity, "Find Hotels", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;

                    case 5:
                        Toast.makeText(activity, "Find Hotels", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;

                    case 6:
                        Toast.makeText(activity, "Find Hotels", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;

                    case 7:
                        Toast.makeText(activity, "Find Hotels", Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, MainActivity.class));
                        break;


                    case 8:
                        AlertDialog.Builder builder = new AlertDialog.Builder(activity);

                        builder.setTitle("Logout");

                        builder.setMessage("Are you sure?");

                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                sessionManager = new SessionManager(activity);
                                sessionManager.logout();
                            }
                        });

                        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        });
                        builder.show();
                        break;




                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout textView;
        TextView text;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.text_view_layout);
            text = itemView.findViewById(R.id.text_view);

        }
    }
}
