package com.smarttravelling.smarttravelling121212;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.smarttravelling.smarttravelling121212.SessionManager.SessionManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Login extends AppCompatActivity {
    EditText email,password;
    TextView signup;
    Button loginbtn;
    ProgressBar progressBar;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sessionManager = new SessionManager(this);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        signup = findViewById(R.id.signup);
        loginbtn = findViewById(R.id.login);
        progressBar = findViewById(R.id.pb);



    }

    public void login(View view) {
        progressBar.setVisibility(View.VISIBLE);
        sessionManager = new SessionManager(this);
        String url = "https://projecttech.xyz/smart_travelling/login.php?user_email="+email.getText().toString()+"&user_password="+password.getText().toString();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, response -> {
            try {
                progressBar.setVisibility(View.GONE);
                JSONObject jsonObject = new JSONObject(response);
                JSONArray jsonArray = jsonObject.getJSONArray("result");
                JSONObject userObject = jsonArray.getJSONObject(0);
                if (!userObject.getString("error").equalsIgnoreCase("no")) {

                    Toast.makeText(Login.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();

                } else {

                    startActivity( new Intent(Login.this, Home.class));
                    sessionManager.createSession(email.getText().toString(),password.getText().toString());
                    Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    finish();
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Login.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        }
        );
        requestQueue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }
}